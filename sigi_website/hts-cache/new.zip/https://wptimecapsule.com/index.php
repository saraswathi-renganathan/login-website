
<!DOCTYPE html>
<html lang="en-us">
	<head>
		<meta charset="utf-8">
		<!--<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">-->

		<title>WP Time Capsule - Update your WordPress with confidence - Incremental WordPress Backup</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

		<!-- CSS -->
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="screen">
		<link href="https://fonts.googleapis.com/css?family=Lato:300,300i,400,400i,700" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="css/fonts.css" media="screen">
        <link rel='stylesheet' type='text/css' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css?ver=4.7.0' media='all' />
        <link rel="stylesheet" type="text/css" href="style.css" media="screen">
				<link rel="stylesheet" type="text/css" href="css/lity.min.css" media="screen">
		<link rel="stylesheet" type="text/css" href="css/responsive.css" media="screen">
		<meta property="og:url" content="https://wptimecapsule.com/" />
		<meta property="og:type" content="product" />
		<meta property="og:title" content="WP Time Capsule - A risk-free backup solution" />
		<meta property="og:description" content="Update security releases automagically with our smart update detection technique." />
		<meta property="og:image" content="https://wptimecapsule.com/images/fbog_new.png" />
		<meta name="twitter:card" content="summary_large_image">
		<meta name="twitter:site" content="@wptimecapsule">
		<meta name="twitter:creator" content="@wptimecapsule">
		<meta name="twitter:title" content="WP Time Capsule - A risk-free backup solution">
		<meta name="twitter:description" content="Update security releases automagically with our smart update detection technique.">
		<meta name="twitter:image" content="https://wptimecapsule.com/images/twitterog.jpg">
		<link rel="shortcut icon" href="img/favicon/favicon.png?v=2" type="image/png">
		<link rel="icon" href="img/favicon/favicon.png?v=2" type="image/png">
	</head>

    <body>

		<header>
			<div class="notification" style="display:none">
				<div class="container">
					<div class="row">
						<div class="col-sm-8 col-xs-12">
							<p><strong>Grab your Lifetime License Now</strong><span class="hidden-xs">, Extended until 13th April 2017.</span> <a href="pricing.php">Grab Now!</a></p>
						</div>
						<div class="col-sm-4 col-xs-12">
							<p class="limit" id="timer_ll"><span class="hidden-xs">Lifetime offer ends in </span><span class="timespan" id="time_countdown">0d : 0h : 0m : 0s</span></p>
						</div>
					</div>
				</div>
			</div>
			<div class="header-main">
				<div class="header-top">
					<div class="container">
						<div class="row">
							<div class="col-lg-4 col-sm-5">
								<div class="logo">
									<a href="index.php">
										<img src="img/logo.png" alt="logo" class="img-responsive" />
									</a>
								</div>
							</div>
							<div class="col-lg-8 col-sm-7">
								<div class="mainmenu">
									<nav class="navbar top-navbar">
										<div class="navbar-header">
											<button data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" class="navbar-toggle" type="button">
												<span class="sr-only">Toggle navigation</span>
												<span class="icon-bar"></span>
												<span class="icon-bar"></span>
												<span class="icon-bar"></span>
											</button>
										</div>
										<div id="bs-example-navbar-collapse-1" class="collapse navbar-collapse">
											<ul class="nav navbar-nav navbar-right">
												<li><a href="features.html">Features</a></li>
												<li><a href="agency/index.html">Agency</a></li>
												<li><a href="/pricing">Pricing</a></li>
												<li><a href="team.html">Team</a></li>
												<li><a href="https://service.wptimecapsule.com/">Login</a></li>
											</ul>
										</div>
									</nav>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="header-bottom">
					<div class="container">
						<div class="caption">
							<h2>Update your WordPress sites with confidence</h2>
							<p>Your WordPress and its updates are safe with our reliable backups! <br/>Gone are the days where you panic about updating your WordPress sites.</p>
						</div>
						<div class="shadow-custom"></div>
						<div class="subscription">
							<form class="form-inline" action="pricing/index.php" method="post">
								<div class="form-group">
									<input type="email" name="mcemail" class="form-control" placeholder="Enter your email" required>
								</div>
								<button type="submit" class="btn btn-default">Get Started For Free!</button>
							</form>
						</div>
						<div class="testimonial">
							<div class="row">
								<div class="col-sm-4 col-xs-3">
									<img src="img/thumbnails/user-2.png" class="img-responsive" />
								</div>
								<div class="col-sm-8 col-xs-8">
									<p>Our website is mission critical to our business. Frequent backups ensure we have fallbacks and peace of mind should anything happen to our data. WP Time Capsule is my goto solution.</p>
									<h4>Devin Walker <img src="img/thumbnails/logo-5.png" /></h4>
								</div>
							</div>
						</div>
						<div class="screen">
							<img src="img/thumbnails/thumbnail-1.png" class="img-responsive" />
						</div>
					</div>
				</div>
			</div>
		</header>

		<div class="content">
			<div class="container">

				<div class="section section-1 service-panel">
					<div class="row">
						<div class="col-sm-12">
							<div class="row">
								<div class="col-lg-4 col-sm-4">
									<div class="service-box service-box-1">
										<div class="service-box-header">
											<h3 style="margin-top:30px;">Set & Forget</h3>
										</div>
										<div class="service-box-content">
											<p>We efficiently auto-backup only the changes every 24 hours.</p>
										</div>
									</div>
								</div>
								<div class="col-lg-4 col-sm-4">
									<div class="service-box service-box-2">
										<div class="service-box-header">
											<h3>Your backups <br/>are private</h3>
										</div>
										<div class="service-box-content">
											<p>Your sites are safely backed up to Google Drive, Amazon S3 and Dropbox.</p>
										</div>
									</div>
								</div>
								<div class="col-lg-4 col-sm-4">
									<div class="service-box service-box-3">
										<div class="service-box-header">
											<h3>Stage updates <br/>to be doubly sure</h3>
										</div>
										<div class="service-box-content">
											<p>Stage an update to check integrity before making the changes live.</p>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="section section-2 typo text-center">
					<div class="row">
						<div class="col-sm-10 col-sm-offset-1">
							<h3>Protect your WordPress even before it can be attacked.</h3>
							<p>Not enabling auto-updates led to defacing tons of WordPress sites due to the REST-API exploit recently. With plenty of solutions available, a lot of WordPress sites still don't have them enabled. WPTC is here to save your site from a bad update and prevent being hacked due to not updating your site on time thus giving you complete peace of mind.</p>
						</div>
					</div>
				</div>

				<div class="section section-3 typo">
					<div class="row screens">
						<div class="col-sm-5 col-xs-5">
							<br/><br/><br/>
							<img src="img/thumbnails/thumbnail-3.png" class="img-responsive" />
						</div>
						<div class="col-xs-2 text-center">
							<img src="img/thumbnails/div-1.png" class="img-responsive" />
						</div>
						<div class="col-sm-5 col-xs-5">
							<br class="hidden-xs"/><br class="hidden-xs"/><br/>
							<h4>Patch your WordPress immediately.</h4>
							<p>With smart update detection techniques, We automagically detect security updates and apply them on your WordPress sites.</p>
						</div>
					</div>
					<div class="row screens screens-2">
						<div class="col-sm-5 col-xs-5">
							<br/><br/><br/>
							<h4>We've got your back for every update.</h4>
							<p>Automatically backs up your WP site whenever an update takes place, be it an auto or a manual update.</p>
						</div>
						<div class="col-xs-2 text-center">
							<img src="img/thumbnails/div-2.png" class="img-responsive" />
						</div>
						<div class="col-sm-5 col-xs-5">
							<img src="img/thumbnails/thumbnail-2.png" class="img-responsive screenshot-2" />
						</div>
					</div>
					<div class="row screens">
						<div class="col-sm-5 col-xs-5">
							<img src="img/thumbnails/thumbnail-4.png" class="img-responsive" />
						</div>
						<div class="col-xs-2 text-center">
							<img src="img/thumbnails/div-3.png" class="img-responsive" />
						</div>
						<div class="col-sm-5 col-xs-5">
							<h4>We make sure if the update went well!</h4>
							<p>Automatically checks your site after every update and notifies you in case of a bad update so that you can restore your site.</p>
						</div>
					</div>
					<div class="text-center">
						<a href="features.html" class="btn btn-link">More features...</a>
					</div>
				</div>

				<div class="section subscription-panel section-4">
					<div class="subscription text-center">
						<form class="form-inline" action="pricing/index.php" method="post">
							<div class="form-group">
								<input type="email" name="mcemail" class="form-control" placeholder="Enter your email" required>
							</div>
							<button type="submit" class="btn btn-default">Get Started For Free!</button>
						</form>
					</div>
				</div>

				<div class="section section-5 how-it-works typo text-center">
					<h3 class="text-center">"How is this better?"</h3>
					<br/>
					<div class="row">
						<div class="col-sm-4 nop-pad">
							<div class="how-box">
								<div class="how-box-header">
									<img src="img/thumbnails/thumbnail-5.png" class="img-responsive" />
								</div>
								<div class="how-box-content">
									<h5>Traditional Backups</h5>
									<ul class="list-unstyled">
										<li>Backups are compressed and zipped<span>Heavy server memory consumption</span></li>
										<li>Multiple zip files are created every time<span>Precious storage space is waste</span></li>
										<li>Unzip backup zip file and restore the whole site<span>Consumes time and server memory</span></li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-sm-4 nop-pad-center">
							<div class="how-list-box">
								<ul class="list-unstyled">
									<li><span class="how-1">Backup Method</span></li>
									<li><span class="how-2">Backup Files</span></li>
									<li><span class="how-3">Restore</span></li>
								</ul>
							</div>
						</div>
						<div class="col-sm-4 nop-pad">
							<div class="how-box">
								<div class="how-box-header">
									<img src="img/thumbnails/thumbnail-6.png" class="img-responsive" />
								</div>
								<div class="how-box-content our-way">
									<h5>WP Time Capsule</h5>
									<ul class="list-unstyled">
										<li>No zipping. Changes are dropped into your cloud app<span class="how-box-desc">Low server memory usage</span></li>
										<li>Backs up incrementally. No multiple copies of files<span class="how-box-desc">Far less storage space usage</span></li>
										<li>Restores specific files + DB or all changed files + DB<span class="how-box-desc">Faster restore</span></li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>

				<div class="section section-5 how-it-works-mobile typo">
					<h3 class="text-center">"How is this better?"</h3>
					<br/><br/><br/>
					<div class="row">
						<div class="col-xs-6">
							<div class="how-box-content">
								<h4>Traditional Backups</h4>
								<br/><br/>
								<img src="img/thumbnails/thumbnail-5-mobile.png" class="img-responsive" />
							</div>
						</div>
						<div class="col-xs-6">
							<div class="how-box-content">
								<h4>WP <br/>Time Capsule</h4>
								<br/><br/>
								<img src="img/thumbnails/thumbnail-6-mobile.png" class="img-responsive" />
							</div>
						</div>
					</div>
					<div class="div-btn">
						<a href="#" class="how-1">Backup Method</a>
					</div>
					<div class="row">
						<div class="col-xs-6">
							<div class="how-box-content right">
								<p>Backups are <br/>compressed and <br/>zipped</p>
								<h5>Heavy server memory consumption</h5>
							</div>
						</div>
						<div class="col-xs-6">
							<div class="how-box-content our-way">
								<p>No zipping. Changes <br/>are dropped into your <br/>cloud app</p>
								<h5>Low server memory usage</h5>
							</div>
						</div>
					</div>
					<div class="div-btn">
						<a href="#" class="how-2">Backup Files</a>
					</div>
					<div class="row">
						<div class="col-xs-6">
							<div class="how-box-content right">
								<p>Multiple zip <br/>files are created every <br/>time</p>
								<h5>Precious storage space is waste</h5>
							</div>
						</div>
						<div class="col-xs-6">
							<div class="how-box-content our-way">
								<p>Backs up incrementally. <br/>No multiple copies of <br/>files</p>
								<h5>Far less storage space usage</h5>
							</div>
						</div>
					</div>
					<div class="div-btn">
						<a href="#" class="how-3">Restore</a>
					</div>
					<div class="row">
						<div class="col-xs-6">
							<div class="how-box-content right">
								<p>Unzip backup zip <br/>file and restore the <br/>whole site</p>
								<h5>Consumes time and server memory</h5>
							</div>
						</div>
						<div class="col-xs-6">
							<div class="how-box-content our-way">
								<p>Restores specific <br/>files + DB or all <br/>changed files + DB</p>
								<h5>Faster restore</h5>
							</div>
						</div>
					</div>
				</div>

				<div class="section section-6 video text-center">
					<a class="video-btn" href="//www.youtube.com/embed/nkCo8Qp4PsM%3Fautoplay=0&loop=0&showinfo=0&theme=dark&color=red&controls=1&modestbranding=0&start=0&fs=1&iv_load_policy=3&wmode=transparent&rel=0" data-lity>
					<img src="img/thumbnails/dummy-video.png" class="img-responsive" />
				</a>
				</div>

				<div class="section section-7 typo features text-center">
					<h3>Comparison with other backup solutions</h3>
					<br/>
					<table>
						<tr>
							<td width="30%"></td>
							<td width="15%"><img src="img/thumbnails/logo-4.png" class="img-responsive" /></td>
							<td width="15%"><img src="img/thumbnails/logo-3.png" class="img-responsive" /></td>
							<td width="15%"><img src="img/thumbnails/logo-2.png" class="img-responsive" /></td>
							<td width="15%"><img src="img/thumbnails/logo-1.png" class="img-responsive" /></td>
						</tr>
						<tr>
							<td><span class="btn-2">Incremental Backup</span></td>
							<td><span class="tick-yes"></span></td>
							<td><span class="tick-no"></span></td>
							<td><span class="tick-no"></span></td>
							<td><span class="tick-yes"></span></td>
						</tr>
						<tr>
							<td><span class="btn-2">Your Own Repository</span></td>
							<td><span class="tick-no"></span></td>
							<td><span class="tick-yes"></span></td>
							<td><span class="tick-yes"></span></td>
							<td><span class="tick-yes"></span></td>
						</tr>
						<tr>
							<td><span class="btn-2">Automatic Website Restore</a></td>
							<td><span class="tick-yes"></span></td>
							<td><span class="tick-yes"></span></td>
							<td><span class="tick-yes"></span></td>
							<td><span class="tick-yes"></span></td>
						</tr>
						<tr>
							<td><span class="btn-2">Stage an update</a></td>
							<td><span class="tick-no"></span></td>
							<td><span class="tick-no"></span></td>
							<td><span class="tick-no"></span></td>
							<td><span class="tick-yes"></span></td>
						</tr>
						<tr>
							<td><span class="btn-2">Backup before update </a></td>
							<td><span class="tick-no"></span></td>
							<td><span class="tick-no"></span></td>
							<td><span class="tick-no"></span></td>
							<td><span class="tick-yes"></span></td>
						</tr>
						<tr>
							<td><span class="btn-2">Cost</a></td>
							<td><span class="cost"><span class="rate">$5</span>/site/month</span></td>
							<td><span class="cost"><span class="rate">$9</span>/site/month</span></td>
							<td><span class="cost"><span class="rate">$12</span>/site/month</span></td>
							<td><span class="cost wtc-cost"><a href="/pricing" style="color:#0acd6f;cursor:pointer"><span class="strike">$4.1</span>/site/month</a></span></td>
						</tr>
						
					</table>
				</div>

				<div class="section section-7 typo features-mobile">
					<h3 class="text-center">Comparison with other <br/>backup solutions</h3>
					<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
						<div class="panel ">
							<div class="panel-heading" role="tab" id="headingOne">
								<a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
								<img src="img/others/icon-1.png" class="img-responsive" />
								<span class="cost"><span class="rate">$5</span>/site/month</span>
								</a>

							</div>
							<div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
								<div class="panel-body">
									<ul>
										<li class="yes">Incremental Backup</li>
										<li class="no">Your Own Repository</li>
										<li class="yes">Automatic Website Restore</li>
										<li class="no">Stage an update</li>
										<li class="no">Backup before update</li>
										<li class="no">Cost</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="panel">
							<div class="panel-heading" role="tab" id="headingTwo">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
									<img src="img/others/icon-2.png" class="img-responsive" />
									<span class="cost"><span class="rate">$9</span>/site/month</span>
								</a>
							</div>
							<div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
								<div class="panel-body">
									<ul>
										<li class="no">Incremental Backup</li>
										<li class="yes">Your Own Repository</li>
										<li class="yes">Automatic Website Restore</li>
										<li class="no">Stage an update</li>
										<li class="no">Backup before update</li>
										<li class="no">Cost</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="panel">
							<div class="panel-heading" role="tab" id="heading3">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse3" aria-expanded="false" aria-controls="collapse3">
									<img src="img/others/icon-3.png" class="img-responsive" />
									<span class="cost"><span class="rate">$12</span>/site/month</span>
								</a>
							</div>
							<div id="collapse3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading2">
								<div class="panel-body">
									<ul>
										<li class="no">Incremental Backup</li>
										<li class="yes">Your Own Repository</li>
										<li class="yes">Automatic Website Restore</li>
										<li class="no">Stage an update</li>
										<li class="no">Backup before update</li>
										<li class="no">Cost</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="panel">
							<div class="panel-heading" role="tab" id="heading4">
								<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse4" aria-expanded="true" aria-controls="collapse3">
									<img src="img/others/icon-4.png" class="img-responsive" />
									<span class="cost wtc-cost"><a href="/pricing" style="color:#0acd6f;cursor:pointer"><span class="rate">$4.1</span>/site/month</a></span>
								</a>
							</div>
							<div id="collapse4" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading4">
								<div class="panel-body">
									<ul>
										<li class="yes">Incremental Backup</li>
										<li class="yes">Your Own Repository</li>
										<li class="yes">Automatic Website Restore</li>
										<li class="yes">Stage an update</li>
										<li class="yes">Backup before update</li>
										<li class="yes">Cost</li>
									</ul>
									
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>

		<footer>
			<div class="footer-testimonial">
				<div class="container">
					<h3 class="text-center">Here's what the WordPress community thinks of WPTC!</h3>
					<br/><br/>
					<div class="row">
						<div class="col-sm-8 col-sm-offset-2">
							<div id="carousel-banner" class="carousel slide" data-ride="carousel">
								<div class="carousel-inner">
										<div class="item active">
											<div class="testimonial">
												<div class="row">
													<div class="col-sm-3">
														<img src="img/thumbnails/user-8.png" class="img-responsive mobile-img" />
													</div>
													<div class="col-sm-9">
														<p>It's considered best practice to backup before updating your site. With WPTC, a helpful reminder prompts me to create a backup before I update. I love that.</p>
														<h4>Devin Walker</h4>
													</div>
												</div>
											</div>
										</div>
										<div class="item">
											<div class="testimonial">
												<div class="row">
													<div class="col-sm-3">
														<img src="img/thumbnails/user-1.png" class="img-responsive mobile-img" />
													</div>
													<div class="col-sm-9">
														<p>This is by far the simplest backup plugin interface I've seen. So much so I think it's replaced my current recommendation of BackupBuddy.</p>
														<h4>Scott Wyden Kivowitz</h4>
													</div>
												</div>
											</div>
										</div>
											<div class="item">
											<div class="testimonial">
												<div class="row">
													<div class="col-sm-3">
														<img src="img/thumbnails/user-6.png" class="img-responsive mobile-img" />
													</div>
													<div class="col-sm-9">
														<p>WP Time Capsule is easy to install. With a few keystrokes you can easily set up scheduled backups for your WordPress site. There is a selection of cloud storage destinations for your backups Including Google Drive (a great bonus as you can get 15 Gb of storage with google by merely signing up) other destinations include Dropbox and Amazon S3. After that Time Capsule takes incremental backs on a scheduled basis. The PRO versions offer the ability to Stage your web site.</p>
														<h4>John Labella</h4>
													</div>
												</div>
											</div>
										</div>
										<div class="item">
											<div class="testimonial">
												<div class="row">
													<div class="col-sm-3">
														<img src="img/thumbnails/user-3.png" class="img-responsive mobile-img" />
													</div>
													<div class="col-sm-9">
														<p>Support (via email) is quickly responding to issues and it seems the dev-team is open to and welcomes suggestions.</p>
														<h4>Piet Bos</h4>
													</div>
												</div>
											</div>
										</div>
										<div class="item">
											<div class="testimonial">
												<div class="row">
													<div class="col-sm-3">
														<img src="img/thumbnails/user-4.png" class="img-responsive mobile-img" />
													</div>
													<div class="col-sm-9">
														<p>WP Time Capsule takes care of daily WordPress backups without hassle. Set it up, do the initial backup and you're done. Using it for more than 15 websites and everything works great. Thanks for creating this great plugin</p>
														<h4>Marcel Bootsman</h4>
													</div>
												</div>
											</div>
										</div>
										<div class="item">
											<div class="testimonial">
												<div class="row">
													<div class="col-sm-3">
														<img src="img/thumbnails/user-5.png" class="img-responsive mobile-img" />
													</div>
													<div class="col-sm-9">
														<p>Incremental All The Way! I like the fact that this is an incremental backups plugin! Tried it and it worked pretty good. Keep up the good work.</p>
														<h4>Ahmad Awais</h4>
													</div>
												</div>
											</div>
										</div>

									</div>
								<ol class="carousel-indicators">
									<li data-target="#carousel-banner" data-slide-to="0" class="active"></li>
									<li data-target="#carousel-banner" data-slide-to="1"></li>
									<li data-target="#carousel-banner" data-slide-to="2"></li>
									<li data-target="#carousel-banner" data-slide-to="3"></li>
									<li data-target="#carousel-banner" data-slide-to="4"></li>
									<li data-target="#carousel-banner" data-slide-to="5"></li>
								</ol>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="footer-top">
				<div class="container">
					<div class="row">
						<div class="col-sm-8 col-xs-6 mobile-box">
							<h3>Made with <i class="fa fa-heart"></i> by InfiniteWP Team</h3>
							<ul class="list-inline">

							    <li><a href="terms.html" target="_blank">Terms</a></li>
								<li class="hidden-xs">|</li>
								<li><a href="/pricing">Pricing</a></li>
								<li class="hidden-xs">|</li>
								<li><a href="features.html">Features</a></li>
								<li class="hidden-xs">|</li>
								<li><a href="team.html">Team</a></li>
								<li class="hidden-xs">|</li>
								<li><a href="http://docs.wptimecapsule.com" target="_blank">Help</a></li>
							</ul>
						</div>
						<div class="col-sm-4 col-xs-6">
							<p>Revmakx LLC</p>
							<p>250, River Run Rd <br/>Boone, NC 28607-5119, US.</p>
						</div>
					</div>
				</div>
			</div>
			<div class="footer-bottom text-center">
				<div class="container">
					<p>Copyright WP Time Capsule - All Rights Reserved <a href="mailto:help@wptimecapsule.com">help@wptimecapsule.com</a></p>
				</div>
			</div>
		</footer>

	    <script type="text/javascript" src="js/modernizr.custom.js" language="javascript"></script>
        <script type="text/javascript" src="js/jquery-1.11.0.min.js" language="javascript"></script>
        <script type="text/javascript" src="js/bootstrap.js" language="javascript"></script>
		<script type="text/javascript" src="js/custom.js" language="javascript"></script>
		<script type="text/javascript" src="js/lity.js" language="javascript"></script>
		<script>
// Set the date we're counting down to
var countDownDate = new Date("Apr 13, 2017 23:59:59").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get todays date and time
  var now = new Date().getTime();

  // Find the distance between now an the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("time_countdown").innerHTML = days + "d: " + hours + "h: "
  + minutes + "m: " + seconds + "s";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("timer_ll").innerHTML = "";
  }
}, 1000);
</script>
<script type="text/javascript">
    window.heap=window.heap||[],heap.load=function(e,t){window.heap.appid=e,window.heap.config=t=t||{};var r=t.forceSSL||"https:"===document.location.protocol,a=document.createElement("script");a.type="text/javascript",a.async=!0,a.src=(r?"https:":"http:")+"//cdn.heapanalytics.com/js/heap-"+e+".js";var n=document.getElementsByTagName("script")[0];n.parentNode.insertBefore(a,n);for(var o=function(e){return function(){heap.push([e].concat(Array.prototype.slice.call(arguments,0)))}},p=["addEventProperties","addUserProperties","clearEventProperties","identify","removeEventProperty","setEventProperties","track","unsetEventProperty"],c=0;c<p.length;c++)heap[p[c]]=o(p[c])};
      heap.load("1723180859");
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-52712815-3', 'auto');
  ga('send', 'pageview');

</script>
<script type="text/javascript">
    adroll_adv_id = "AS4XB3JTYVFWXIJF3NRAB3";
    adroll_pix_id = "ELFBHJ5UDVF6BG4RNVI2XV";
    /* OPTIONAL: provide email to improve user identification */
    /* adroll_email = "username@example.com"; */
    (function () {
        var _onload = function(){
            if (document.readyState && !/loaded|complete/.test(document.readyState)){setTimeout(_onload, 10);return}
            if (!window.__adroll_loaded){__adroll_loaded=true;setTimeout(_onload, 50);return}
            var scr = document.createElement("script");
            var host = (("https:" == document.location.protocol) ? "https://s.adroll.com" : "http://a.adroll.com");
            scr.setAttribute('async', 'true');
            scr.type = "text/javascript";
            scr.src = host + "/j/roundtrip.js";
            ((document.getElementsByTagName('head') || [null])[0] ||
                document.getElementsByTagName('script')[0].parentNode).appendChild(scr);
        };
        if (window.addEventListener) {window.addEventListener('load', _onload, false);}
        else {window.attachEvent('onload', _onload)}
    }());
</script>
    </body>
</html>